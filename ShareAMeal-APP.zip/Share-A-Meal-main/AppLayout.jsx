import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-background font-sans">
      <Navbar />
      <main>
        <Outlet />
      </main>
    </div>
  );
}
